/** Hangman Manager Class to manage hangman.
 * @author Michealea Faustine
 * @version 1.0 (01/28/2021)
 */

import java.util.*;
import java.io.*;

public class HangmanManager{
   private int length;
   private int max;
   private String currentPattern;
   private SortedSet<Character> sortedCh;
   private Set<String> currentWords;
   
   /* constructor for HangmanManager */
   public HangmanManager(List<String> Dictionary, int length, int max){
      if(length<1||max<0){
         
         throw new IllegalArgumentException();
      }
      this.length=length;
      this.max=max;
      currentWords= new TreeSet<String> ();
      Iterator<String> list= Dictionary.iterator();
      sortedCh= new TreeSet<Character>(); //create a sorted set 
      for (String word: Dictionary){
         if(word.length()==length){
            currentWords.add(word);
         }
      }
      this.currentPattern="";
      for (int i=0;i<length; i++){
            this.currentPattern+="- ";
      }
   }
   
   /** current set of words 
    *
    * @return set<String> of words considered by the hangman Manager
    */ 
   public Set<String> words(){
      return currentWords;
   }
  
   /** find how many guesses left
    *
    * @return int number of guesses the player has left
    */
   public int guessesLeft(){
      return max;
   }
   
   /** current set of letters sorted
    *
    * @return SortedSet the set of letters guessed by the user
    */ 
   public SortedSet<Character> guesses(){  
      return sortedCh;  
   }
   
   /**The patterns showing the guessed characters
    *
    * @return String pattern to be displayed, and there should be spaces
    *         separating the letters, letters that have not been guessed
    *         are represented by dashes
    */ 
   public String pattern(){
      if(currentWords.size()<0){
         throw new IllegalStateException();
      }
      else {
         return currentPattern;
      }
   }
   
   /** record all the user's guesses and next guesses, update the currentWords and the currentPattern 
    * @param char guess made by the user
    * @return int number of occurrences of the guessed letter in the new pattern
    *         and update how many guesses left
    */ 
   public int record(char guess){
      if(max < 1 || currentWords.isEmpty()){
			throw new IllegalStateException("");
		}
      if(!currentWords.isEmpty() && sortedCh.contains(guess)){ 
         throw new IllegalArgumentException();
      }
      int count=0; 
      Map<String, Set<String>> wordMap= new TreeMap<String, Set<String>>();
      find(wordMap,guess);
      count=occurence(guess);
      if (count == 0) {
            max--;
        }
      return count;
   }
   
   private int occurence(char guess) {
        int count = 0;
        for (int i = 0; i < currentPattern.length(); i++) {
            if (currentPattern.charAt(i) == guess) {
                count++;
            }
        }
        sortedCh.add(guess);
        return count;
   }
   
   private String pattern(String word, char guess){
      String newPattern= currentPattern;
      for (int i=0;i<word.length(); i++){
         if(word.charAt(i)==guess){
            newPattern= newPattern.substring(0,i)+ guess+ newPattern.substring(i+1);
         }
      }
      return newPattern;
   }
   
   private void find(Map<String, Set<String>> wordMap, char guess){
      for(String word: currentWords){
         String newPattern= pattern(word,guess); 
         Set<String> s= new TreeSet<String>();
         if (!wordMap.containsKey(newPattern)){
            wordMap.put(newPattern, s);         
         }
         else {
            wordMap.get(newPattern).add(word);
         }
      }
      int largestSize=0;
      for (String pattern: wordMap.keySet()){
         Set<String> words= wordMap.get(pattern);
         if (words.size()> largestSize){
            largestSize= words.size();
            currentWords= words;
            currentPattern= pattern;
         }
      }
   }
}
